#ifndef MAIN

#include "fcfs.h"
int dispatch_level1(FILE* input_list_stream, int timer);

#endif // !MAIN
