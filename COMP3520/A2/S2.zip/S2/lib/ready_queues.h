#ifndef READY_QUEUES

#include "pcb.h"

/* Function Prototypes */

PcbPtr lv1_start(PcbPtr pcb, int quantam);
PcbPtr lv2_start(PcbPtr pcb, int quantam);
PcbPtr lv3_start(PcbPtr pcb);

#endif // !READY_QUEUES
