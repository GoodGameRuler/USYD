#include "ready_queues.h"
#include "pcb.h"

PcbPtr lv1_start(PcbPtr pcb, int quantum) {
    return NULL;
}

PcbPtr lv2_start(PcbPtr pcb, int quantum) {
    return NULL;
}

PcbPtr lv3_start(PcbPtr pcb) {
    return NULL;
}
