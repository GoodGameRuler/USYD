package invaders.entities;

public interface Projectile {
}
