package invaders.entities.States;

import javafx.scene.image.Image;

public interface BunkerColorState {
    public Image returnImage();
}