use gradle run to run program
