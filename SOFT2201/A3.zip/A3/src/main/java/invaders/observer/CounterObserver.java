package invaders.observer;

public interface CounterObserver {
    public void update();
}
