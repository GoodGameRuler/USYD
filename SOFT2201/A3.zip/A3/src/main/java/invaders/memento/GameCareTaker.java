package invaders.memento;

public interface GameCareTaker {
    public void undo();
    public void save();
}
