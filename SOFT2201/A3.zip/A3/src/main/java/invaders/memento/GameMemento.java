package invaders.memento;

public interface GameMemento {
    public void undo();
}
